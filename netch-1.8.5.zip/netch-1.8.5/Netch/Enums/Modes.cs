﻿namespace Netch.Enums
{
    public enum ModeType
    {
        Process = 0,
        ProxyRuleIPs = 1,
        BypassRuleIPs = 2,
        Pcap2Socks = 6
    }
}